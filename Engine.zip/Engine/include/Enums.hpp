#pragma once

enum AppState
{
    quit,
    init,
    run 
};