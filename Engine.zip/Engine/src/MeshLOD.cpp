#include <MeshLOD.hpp>

void update(bool forceUpdate = false)
{
    
}