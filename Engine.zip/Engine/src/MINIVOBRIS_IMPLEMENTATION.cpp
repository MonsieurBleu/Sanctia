#define OGG_IMPL
#define VORBIS_IMPL
#include "minivorbis.h"